# H200 GPU Performance Lab

Goal: spend time interpreting Nsight Systems / Nsight Compute rather than fighting launch mechanics.

## Quick start

```bash
./scripts/build.sh
./scripts/run.sh
./scripts/nsys.sh
./scripts/ncu.sh
```

## Experiments

1. **Coalescing:** stride 1 vs stride 32. Predict transaction efficiency, L2/HBM traffic, and bandwidth before profiling.
2. **Dependency / ILP:** one dependent arithmetic chain vs 4 independent chains per thread. Predict issue efficiency and dependency stalls.
3. **MLP:** one pointer-chase chain vs 4 independent chains. Predict outstanding memory concurrency, scoreboard stalls, and achieved bandwidth.

## Analysis template

For every report write:

- Prediction
- Observation
- Classification: frontend/issue, compute, latency/MLP, bandwidth, occupancy/resource
- Evidence
- Hypothesis
- Validation experiment
- Conclusion

## Nsys questions

- Are there unexpected CPU-side gaps between launches?
- Are kernels serialized or overlapping as expected?
- Is launch/synchronization overhead material relative to kernel time?

## NCU questions

- What is the dominant warp stall reason?
- How many warps are eligible/active relative to theoretical occupancy?
- Is SM throughput high or low?
- Is memory throughput near a hardware ceiling?
- Is L2 helping?
- Does stride increase sectors/transactions per useful byte?
- Does 4-chain MLP reduce long dependency stalls and raise achieved memory throughput?

## Important interpretation rule

A high memory-stall count does **not** prove bandwidth saturation. Separate latency/MLP limitation from bandwidth limitation.

## Follow-on LLM lab

After these kernels: profile a single H200 LLM request (concurrency 1), identify prefill vs decode in Nsys, then use NCU on one representative kernel from each phase. Only after that move to multi-turn/prefix-cache profiling.
