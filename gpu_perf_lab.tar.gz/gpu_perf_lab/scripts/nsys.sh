#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/results"
nsys profile --force-overwrite=true --trace=cuda,nvtx,osrt --stats=true -o "$ROOT/results/coalescing_stride1" "$ROOT/build/coalescing" 1
nsys profile --force-overwrite=true --trace=cuda,nvtx,osrt --stats=true -o "$ROOT/results/coalescing_stride32" "$ROOT/build/coalescing" 32
