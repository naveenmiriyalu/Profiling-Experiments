#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
"$ROOT/build/coalescing" 1
"$ROOT/build/coalescing" 32
"$ROOT/build/dependency" dep
"$ROOT/build/dependency" indep
"$ROOT/build/mlp" 1
"$ROOT/build/mlp" 4
