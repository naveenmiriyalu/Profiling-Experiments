#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/results"
# Start with the curated section set; use --set full only when you deliberately want a heavy capture.
COMMON=(--force-overwrite --set detailed --kernel-name-base demangled --launch-count 1)
ncu "${COMMON[@]}" -o "$ROOT/results/coalescing_stride1" "$ROOT/build/coalescing" 1
ncu "${COMMON[@]}" -o "$ROOT/results/coalescing_stride32" "$ROOT/build/coalescing" 32
ncu "${COMMON[@]}" -o "$ROOT/results/dependency_dep" "$ROOT/build/dependency" dep
ncu "${COMMON[@]}" -o "$ROOT/results/dependency_indep" "$ROOT/build/dependency" indep
ncu "${COMMON[@]}" -o "$ROOT/results/mlp_1" "$ROOT/build/mlp" 1
ncu "${COMMON[@]}" -o "$ROOT/results/mlp_4" "$ROOT/build/mlp" 4
