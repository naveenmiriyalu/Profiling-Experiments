#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/build" "$ROOT/results"
nvcc -O3 -lineinfo "$ROOT/src/coalescing.cu" -o "$ROOT/build/coalescing"
nvcc -O3 -lineinfo "$ROOT/src/dependency.cu" -o "$ROOT/build/dependency"
nvcc -O3 -lineinfo "$ROOT/src/mlp.cu" -o "$ROOT/build/mlp"
echo "Built in $ROOT/build"
