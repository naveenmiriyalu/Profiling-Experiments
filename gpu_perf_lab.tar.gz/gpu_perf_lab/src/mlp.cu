#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>
#include <string>

#define CUDA_CHECK(x) do { cudaError_t e=(x); if(e!=cudaSuccess){fprintf(stderr,"CUDA error %s:%d: %s\n",__FILE__,__LINE__,cudaGetErrorString(e)); exit(1);} } while(0)

__global__ void chase1(const int* next, unsigned long long* out, int steps, int n){
    int tid=blockIdx.x*blockDim.x+threadIdx.x; int p=(tid*977)%n;
    #pragma unroll 1
    for(int i=0;i<steps;i++) p=next[p];
    out[tid]=p;
}
__global__ void chase4(const int* next, unsigned long long* out, int steps, int n){
    int tid=blockIdx.x*blockDim.x+threadIdx.x;
    int a=(tid*977)%n,b=(a+n/4)%n,c=(a+n/2)%n,d=(a+3*n/4)%n;
    #pragma unroll 1
    for(int i=0;i<steps;i++){ a=next[a]; b=next[b]; c=next[c]; d=next[d]; }
    out[tid]=(unsigned long long)a+b+c+d;
}
int main(int argc,char**argv){
    bool four=argc>1 && std::string(argv[1])=="4";
    int n=64*1024*1024, steps=1024, threads=256, blocks=256;
    int *h=(int*)malloc((size_t)n*sizeof(int));
    // deterministic permutation-like stride; intentionally large working set
    const int step=104729; for(int i=0;i<n;i++) h[i]=(i+step)%n;
    int* d; unsigned long long* out; size_t nt=(size_t)threads*blocks;
    CUDA_CHECK(cudaMalloc(&d,(size_t)n*sizeof(int))); CUDA_CHECK(cudaMemcpy(d,h,(size_t)n*sizeof(int),cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMalloc(&out,nt*sizeof(unsigned long long))); free(h);
    for(int i=0;i<2;i++){ if(four) chase4<<<blocks,threads>>>(d,out,steps,n); else chase1<<<blocks,threads>>>(d,out,steps,n); }
    CUDA_CHECK(cudaDeviceSynchronize());
    cudaEvent_t a,b; CUDA_CHECK(cudaEventCreate(&a)); CUDA_CHECK(cudaEventCreate(&b)); CUDA_CHECK(cudaEventRecord(a));
    if(four) chase4<<<blocks,threads>>>(d,out,steps,n); else chase1<<<blocks,threads>>>(d,out,steps,n);
    CUDA_CHECK(cudaEventRecord(b)); CUDA_CHECK(cudaEventSynchronize(b)); float ms; CUDA_CHECK(cudaEventElapsedTime(&ms,a,b));
    printf("chains=%d kernel_ms=%.3f\n",four?4:1,ms); CUDA_CHECK(cudaFree(d)); CUDA_CHECK(cudaFree(out));
}
