#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>
#include <string>

#define CUDA_CHECK(x) do { cudaError_t e=(x); if(e!=cudaSuccess){fprintf(stderr,"CUDA error %s:%d: %s\n",__FILE__,__LINE__,cudaGetErrorString(e)); exit(1);} } while(0)

__global__ void copy_kernel(const float* __restrict__ in, float* __restrict__ out, size_t n, int stride) {
    size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    size_t idx = tid * (size_t)stride;
    if (idx < n) out[idx] = in[idx] + 1.0f;
}

int main(int argc, char** argv) {
    int stride = argc > 1 ? std::atoi(argv[1]) : 1;
    size_t useful_elems = 64ull * 1024 * 1024; // enough work for profiling
    size_t n = useful_elems * (size_t)stride;
    size_t bytes = n * sizeof(float);
    float *d_in=nullptr, *d_out=nullptr;
    CUDA_CHECK(cudaMalloc(&d_in, bytes));
    CUDA_CHECK(cudaMalloc(&d_out, bytes));
    CUDA_CHECK(cudaMemset(d_in, 0, bytes));
    int threads=256;
    int blocks=(int)((useful_elems + threads - 1)/threads);
    for(int i=0;i<3;i++) copy_kernel<<<blocks,threads>>>(d_in,d_out,n,stride);
    CUDA_CHECK(cudaDeviceSynchronize());
    cudaEvent_t a,b; CUDA_CHECK(cudaEventCreate(&a)); CUDA_CHECK(cudaEventCreate(&b));
    CUDA_CHECK(cudaEventRecord(a));
    copy_kernel<<<blocks,threads>>>(d_in,d_out,n,stride);
    CUDA_CHECK(cudaEventRecord(b)); CUDA_CHECK(cudaEventSynchronize(b));
    float ms=0; CUDA_CHECK(cudaEventElapsedTime(&ms,a,b));
    printf("stride=%d useful_elems=%zu kernel_ms=%.3f\n",stride,useful_elems,ms);
    CUDA_CHECK(cudaFree(d_in)); CUDA_CHECK(cudaFree(d_out));
}
