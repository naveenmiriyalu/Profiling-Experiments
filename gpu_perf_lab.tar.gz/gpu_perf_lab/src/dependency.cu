#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>

#define CUDA_CHECK(x) do { cudaError_t e=(x); if(e!=cudaSuccess){fprintf(stderr,"CUDA error %s:%d: %s\n",__FILE__,__LINE__,cudaGetErrorString(e)); exit(1);} } while(0)

__device__ __forceinline__ float f(float x){ return fmaf(x,1.000001f,0.000001f); }

__global__ void dep_kernel(float* out, int iters){
    int tid=blockIdx.x*blockDim.x+threadIdx.x; float x=1.0f+tid*1e-7f;
    #pragma unroll 1
    for(int i=0;i<iters;i++){ x=f(x); x=f(x); x=f(x); x=f(x); }
    out[tid]=x;
}

__global__ void indep4_kernel(float* out, int iters){
    int tid=blockIdx.x*blockDim.x+threadIdx.x;
    float a=1.0f+tid*1e-7f,b=2.0f,c=3.0f,d=4.0f;
    #pragma unroll 1
    for(int i=0;i<iters;i++){ a=f(a); b=f(b); c=f(c); d=f(d); }
    out[tid]=a+b+c+d;
}

int main(int argc,char**argv){
    bool indep=argc>1 && std::string(argv[1])=="indep";
    int threads=256, blocks=256, iters=20000; size_t n=(size_t)threads*blocks;
    float* out; CUDA_CHECK(cudaMalloc(&out,n*sizeof(float)));
    for(int i=0;i<2;i++){ if(indep) indep4_kernel<<<blocks,threads>>>(out,iters); else dep_kernel<<<blocks,threads>>>(out,iters); }
    CUDA_CHECK(cudaDeviceSynchronize());
    cudaEvent_t a,b; CUDA_CHECK(cudaEventCreate(&a)); CUDA_CHECK(cudaEventCreate(&b)); CUDA_CHECK(cudaEventRecord(a));
    if(indep) indep4_kernel<<<blocks,threads>>>(out,iters); else dep_kernel<<<blocks,threads>>>(out,iters);
    CUDA_CHECK(cudaEventRecord(b)); CUDA_CHECK(cudaEventSynchronize(b)); float ms; CUDA_CHECK(cudaEventElapsedTime(&ms,a,b));
    printf("mode=%s kernel_ms=%.3f\n",indep?"indep4":"dep",ms); CUDA_CHECK(cudaFree(out));
}
