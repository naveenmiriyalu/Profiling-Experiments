# Coherence / Consistency / Atomicity Refresh Problems

1. MOESI: Core 0 has X in M. Core 1 reads X. Walk state/data transitions.
2. MOESI: Core 0 has X in M. Core 1 writes X. Walk ownership and invalidation.
3. Both cores have X in S. Core 0 writes X. What happens?
4. Two threads write different words of the same line. Name the phenomenon and design a falsification experiment.
5. One writer + N readers poll one line. Predict visibility latency as N grows. What curve suggests serialization? What curve suggests saturation?
6. Same-socket latency is flat; cross-socket latency jumps. Give hypothesis + experiment.
7. Median stays flat but P99 grows with readers. Give 3 possible causes and one discrimination experiment.
8. Coherence: Core 0 writes X=1 then X=2. Can Core 1 read 2 then later 1? Why?
9. SC litmus: C0 {X=1; r1=Y;} C1 {Y=1; r2=X;}. Can r1=r2=0? Prove by ordering.
10. TSO: explain how store buffers make r1=r2=0 possible in the same litmus.
11. Why does STORE X=1; LOAD X not read stale X under TSO?
12. Define coherence vs consistency vs atomicity in one sentence each.
13. Producer writes data then release-stores flag; consumer acquire-loads flag then data. What is guaranteed?
14. Replace consumer acquire with relaxed. What guarantee disappears?
15. Why does an atomic relaxed flag not by itself order surrounding data?
16. LR/SC: what invalidates/breaks a reservation, and what does software do after SC failure?
17. What does a fence guarantee conceptually? Why must you avoid saying every fence simply 'flushes all stores'?
18. GPU: SM0 writes global data then flag; SM1 observes flag. What synchronization is needed to safely consume data?
