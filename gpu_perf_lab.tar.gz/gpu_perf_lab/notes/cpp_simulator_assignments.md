# C++ Modeling Assignments

## 1. Producer -> FIFO -> Consumer
Implement a cycle counter, current-state/next-state semantics, finite FIFO capacity, producer/consumer intervals, stall counters, average occupancy, throughput. Then extend to two pipeline stages.

## 2. MESI/MOESI State Machine
Start with 2 cores and 1 line. Operations READ(core), WRITE(core). Print before/event/after states. Count invalidations, ownership requests, cache-to-cache transfers. Add O state after MESI works. Then scale conceptually to 1 writer + N readers.

## 3. SC vs TSO Litmus Simulator
Implement 2 cores, tiny instruction streams, and global memory. First SC. Then add per-core FIFO store buffers so stores drain later while younger loads to other addresses may execute. Enumerate/seed schedules and demonstrate why (r1=0,r2=0) differs. Add a FENCE operation.

## 4. GPU Warp Scheduler Toy Model
SM has N resident warps. Each warp is an in-order stream of ALU(latency=4), L2_LOAD(latency=100), HBM_LOAD(latency=400), USE. Maintain a scoreboard/ready cycle. Each simulated cycle choose an eligible warp and issue. Sweep 4/8/16/32 warps and then 1/2/4 independent loads before USE. Report cycles, issue-slot utilization, eligible warps, and memory concurrency.

Rule: write these yourself. Use the listed behavior as tests; do not start from a completed implementation.
